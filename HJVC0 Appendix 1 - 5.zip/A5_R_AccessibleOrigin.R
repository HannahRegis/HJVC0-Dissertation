# Origin
Origin <- read.csv("UrbanO.csv",header = TRUE, sep = ',')
ORow<- nrow(Origin)

# Destination

C<- read.csv("URB_C_SM3.csv",header = TRUE,sep = ',')
W<- read.csv("URB_W_SM3.csv",header = TRUE,sep = ',')
PT<- read.csv("URB_PT_SM3.csv",header = TRUE,sep = ',')

# Aggregation

C1 <- aggregate(C[,12],by=list(C$OriginId),FUN = "mean")
W1 <- aggregate(W[,12],by=list(W$OriginId),FUN = "mean")
PT1 <- aggregate(PT[,11],by=list(PT$OriginId),FUN = "mean")

# Row Count
wRow <- nrow(W1)
CRow <- nrow(C1)
PTRow <- nrow(PT1)

# R Bind & Merge
Out1 <- rbind.data.frame(wRow,CRow,PTRow)
colnames(Out1)[1] = "Output Row"
Out1['Origin Row'] <- ORow
Out1['Difference'] <- (Out1$`Origin Row`-Out1$`Output Row`)
Out1['Percentage'] <- round(((Out1$`Output Row`/Out1$`Origin Row`)*100),1)
Mode = c("Walk", "Cycle", "PT")
Out1['Travel Mode'] <- Mode
Out1['Destination'] <- "SM"
Out1['Area'] <- "Urban LSOA"
Out1

# Export 

write.csv(Out1,file="01U_ODS_SM.csv",row.names = FALSE)


# FINAL

GP1<- read.csv("01U_ODS_GP.csv",header = TRUE,sep = ',')
HE1<- read.csv("01U_ODS_HE.csv",header = TRUE,sep = ',')
PS1<- read.csv("01U_ODS_PS.csv",header = TRUE,sep = ',')
SM1<- read.csv("01U_ODS_SM.csv",header = TRUE,sep = ',')
SS1<- read.csv("01U_ODS_SS.csv",header = TRUE,sep = ',')
TC1<- read.csv("01U_ODS_TC.csv",header = TRUE,sep = ',')
TS1<- read.csv("01U_ODS_TS.csv",header = TRUE,sep = ',')


FINAL <- rbind.data.frame(GP1,HE1,PS1,SM1,SS1,TC1,TS1)
FINAL

write.csv(FINAL,file="01_ODS_FINAL_Urban.csv",row.names = FALSE)

