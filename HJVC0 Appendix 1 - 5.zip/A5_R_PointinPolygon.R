library("sp")
library("rgeos")
library("tmap")
library("rgdal")
library(rgeos)

# POPULATION WEIGHTED CENTROIDS

P1<- read.csv("02_BUAPWC.csv",header = TRUE,sep = ',')
names(P1) #X #Y
XY <- cbind(Easting = P1$X, Northing = P1$Y)
bng <- "+init=epsg:27700" #BNG, British National Grid
Cent <- SpatialPointsDataFrame(XY, P1[, -(1:2)], 
                               proj4string = CRS(bng))
Cent$objectid <- NULL
Cent$lsoa11cd<- NULL
Cent$lsoa11nm<- NULL
head(Cent@data)
plot(Cent)

# ISOCHRONE LOAD

# RURAL

WD <- getwd()
ISO1 <- readOGR(dsn = WD, layer = "Wat_PT_GP",)
proj4string(ISO1) <- CRS("+init=epsg:27700") 
ISO2 <- readOGR(dsn = WD, layer = "HH_PT_GP",)
proj4string(ISO2) <- CRS("+init=epsg:27700") 
ISO3 <- readOGR(dsn = WD, layer = "SVG_PT_GP",)
proj4string(ISO3) <- CRS("+init=epsg:27700") 
ISO4 <- readOGR(dsn = WD, layer = "ST_PT_GP",)
proj4string(ISO4) <- CRS("+init=epsg:27700")
ISO5 <- readOGR(dsn = WD, layer = "WGC_PT_GP",)
proj4string(ISO5) <- CRS("+init=epsg:27700") 

# ESTABLISHING REPEATED PARAMETERS

Mode <- "PT"
Destination <- "GP"

#/\/\/\/\/\/\/\/\

# SUBSET ISOCHRONES

# RURAL

colnames(ISO1@data)[2]="Time"
T10 <- subset(ISO1, ISO1$Time==10)
T20 <- subset(ISO1, ISO1$Time==20)
T30 <- subset(ISO1, ISO1$Time==30)

colnames(ISO2@data)[2]="Time"
T11 <- subset(ISO2, ISO2$Time==10)
T22 <- subset(ISO2, ISO2$Time==20)
T33 <- subset(ISO2, ISO2$Time==30)

colnames(ISO3@data)[2]="Time"
T111 <- subset(ISO3, ISO3$Time==10)
T222 <- subset(ISO3, ISO3$Time==20)
T333 <- subset(ISO3, ISO3$Time==30)


colnames(ISO4@data)[2]="Time"
T1111 <- subset(ISO4, ISO4$Time==10)
T2222 <- subset(ISO4, ISO4$Time==20)
T3333 <- subset(ISO4, ISO4$Time==30)

colnames(ISO5@data)[2]="Time"
T11111 <- subset(ISO5, ISO5$Time==10)
T22222 <- subset(ISO5, ISO5$Time==20)
T33333 <- subset(ISO5, ISO5$Time==30)


# POINT IN POLYGON ANALYSIS

# Watford

o10 <- over(T10,Cent,returnList=TRUE)
Pop10 <- lapply(o10,colSums)
Pop_10<- data.frame(matrix(unlist(Pop10),nrow=length(Pop10), byrow=T))
colnames(Pop_10)[1] <- "Population"
ANS10<- sum(Pop_10$Population)
o20 <- over(T20,Cent,returnList=TRUE)
Pop20 <- lapply(o20,colSums)
Pop_20<- data.frame(matrix(unlist(Pop20),nrow=length(Pop20), byrow=T))
colnames(Pop_20)[1] <- "Population"
ANS20<- sum(Pop_20$Population)
o30 <- over(T30,Cent,returnList=TRUE)
Pop30 <- lapply(o30,colSums)
Pop_30<- data.frame(matrix(unlist(Pop30),nrow=length(Pop30), byrow=T))
colnames(Pop_30)[1] <- "Population"
ANS30 <- sum(Pop_30$Population)
WFD <- rbind.data.frame(ANS10,ANS20,ANS30)
colnames(WFD)[1]="Population"
WFD$Time <- c("10","20","30")
WFD$Area <- "Watford"
WFD$Mode <- Mode
WFD$Destination <- Destination
WFD

# Hemel

o11 <- over(T11,Cent,returnList=TRUE)
Pop11 <- lapply(o11,colSums)
Pop_11<- data.frame(matrix(unlist(Pop11),nrow=length(Pop11), byrow=T))
colnames(Pop_11)[1] <- "Population"
ANS11<- sum(Pop_11$Population)
ANS11
o22 <- over(T22,Cent,returnList=TRUE)
Pop22 <- lapply(o22,colSums)
Pop_22<- data.frame(matrix(unlist(Pop22),nrow=length(Pop22), byrow=T))
colnames(Pop_22)[1] <- "Population"
ANS22<- sum(Pop_22$Population)
o33 <- over(T33,Cent,returnList=TRUE)
Pop33 <- lapply(o33,colSums)
Pop_33<- data.frame(matrix(unlist(Pop33),nrow=length(Pop33), byrow=T))
colnames(Pop_33)[1] <- "Population"
ANS33 <- sum(Pop_33$Population)
HH <- rbind.data.frame(ANS11,ANS22,ANS33)
colnames(HH)[1]="Population"
HH$Time <- c("10","20","30")
HH$Area <- "Hemel Hempstead"
HH$Mode <- Mode
HH$Destination <- Destination
HH

# Stevenage

o111 <- over(T111,Cent,returnList=TRUE)
Pop111 <- lapply(o111,colSums)
Pop_111<- data.frame(matrix(unlist(Pop111),nrow=length(Pop111), byrow=T))
colnames(Pop_111)[1] <- "Population"
ANS111<- sum(Pop_111$Population)
ANS111
o222 <- over(T222,Cent,returnList=TRUE)
Pop222 <- lapply(o222,colSums)
Pop_222<- data.frame(matrix(unlist(Pop222),nrow=length(Pop222), byrow=T))
colnames(Pop_222)[1] <- "Population"
ANS222<- sum(Pop_222$Population)
o333 <- over(T333,Cent,returnList=TRUE)
Pop333 <- lapply(o333,colSums)
Pop_333<- data.frame(matrix(unlist(Pop333),nrow=length(Pop333), byrow=T))
colnames(Pop_333)[1] <- "Population"
ANS333 <- sum(Pop_333$Population)
SVG <- rbind.data.frame(ANS111,ANS222,ANS333)
colnames(SVG)[1]="Population"
SVG$Time <- c("10","20","30")
SVG$Area <- "Stevenage"
SVG$Mode <- Mode
SVG$Destination <- Destination
SVG

# St Albans

o1111 <- over(T1111,Cent,returnList=TRUE)
Pop1111 <- lapply(o1111,colSums)
Pop_1111<- data.frame(matrix(unlist(Pop1111),nrow=length(Pop1111), byrow=T))
colnames(Pop_1111)[1] <- "Population"
ANS1111<- sum(Pop_1111$Population)
ANS1111
o2222 <- over(T2222,Cent,returnList=TRUE)
Pop2222 <- lapply(o2222,colSums)
Pop_2222<- data.frame(matrix(unlist(Pop2222),nrow=length(Pop2222), byrow=T))
colnames(Pop_2222)[1] <- "Population"
ANS2222<- sum(Pop_2222$Population)
o3333 <- over(T3333,Cent,returnList=TRUE)
Pop3333 <- lapply(o3333,colSums)
Pop_3333<- data.frame(matrix(unlist(Pop3333),nrow=length(Pop3333), byrow=T))
colnames(Pop_3333)[1] <- "Population"
ANS3333 <- sum(Pop_3333$Population)
STA <- rbind.data.frame(ANS1111,ANS2222,ANS3333)
colnames(STA)[1]="Population"
STA$Time <- c("10","20","30")
STA$Area <- "St Albans"
STA$Mode <- Mode
STA$Destination <- Destination
STA

# Welwyn Garden City

o11111 <- over(T11111,Cent,returnList=TRUE)
Pop11111 <- lapply(o11111,colSums)
Pop_11111<- data.frame(matrix(unlist(Pop11111),nrow=length(Pop11111), byrow=T))
colnames(Pop_11111)[1] <- "Population"
ANS11111<- sum(Pop_11111$Population)
o22222 <- over(T22222,Cent,returnList=TRUE)
Pop22222 <- lapply(o22222,colSums)
Pop_22222<- data.frame(matrix(unlist(Pop22222),nrow=length(Pop22222), byrow=T))
colnames(Pop_22222)[1] <- "Population"
ANS22222<- sum(Pop_22222$Population)
o33333 <- over(T33333,Cent,returnList=TRUE)
Pop33333 <- lapply(o33333,colSums)
Pop_33333<- data.frame(matrix(unlist(Pop33333),nrow=length(Pop33333), byrow=T))
colnames(Pop_33333)[1] <- "Population"
ANS33333 <- sum(Pop_33333$Population)
WGC <- rbind.data.frame(ANS11111,ANS22222,ANS33333)
colnames(WGC)[1]="Population"
WGC$Time <- c("10","20","30")
WGC$Area <- "Welwyn Garden City"
WGC$Mode <- Mode
WGC$Destination <- Destination
WGC

##########

W_GP <- rbind.data.frame(WFD,HH,SVG,STA,WGC)
W_GP

C_GP <- rbind.data.frame(WFD,HH,SVG,STA,WGC)
C_GP

PT_GP <- rbind.data.frame(WFD,HH,SVG,STA,WGC)
PT_GP


W_WFDT <- subset(W_GP, W_GP$Area=="Watford")
W_WFDT  <- sum(W_WFDT$Population)
W_HHT <- subset(W_GP, W_GP$Area=="Hemel Hempstead")
W_HHT  <- sum(W_HHT$Population)
W_SVGT <- subset(W_GP, W_GP$Area=="Stevenage")
W_SVGT  <- sum(W_SVGT$Population)
W_STAT <- subset(W_GP, W_GP$Area=="St Albans")
W_STAT  <- sum(W_STAT$Population)
W_WGCT <- subset(W_GP, W_GP$Area=="Welwyn Garden City")
W_WGCT  <- sum(W_WGCT$Population)
TW <- rbind.data.frame(W_WFDT,W_HHT,W_SVGT,W_STAT,W_WGCT)
colnames(TW)[1]="Total Pop"
TW$Area <- c("Watford","Hemel Hempstead","Stevenage","St Albans","Welwyn Garden City")
TW$Mode <- "W"
TW$Destination <- Destination
TW

C_WFDT <- subset(C_GP, C_GP$Area=="Watford")
C_WFDT  <- sum(C_WFDT$Population)
C_HHT <- subset(C_GP, C_GP$Area=="Hemel Hempstead")
C_HHT  <- sum(C_HHT$Population)
C_SVGT <- subset(C_GP, C_GP$Area=="Stevenage")
C_SVGT  <- sum(C_SVGT$Population)
C_STAT <- subset(C_GP, C_GP$Area=="St Albans")
C_STAT  <- sum(C_STAT$Population)
C_WGCT <- subset(C_GP, C_GP$Area=="Welwyn Garden City")
C_WGCT  <- sum(C_WGCT$Population)
GP <- rbind.data.frame(C_WFDT,C_HHT,C_SVGT,C_STAT,C_WGCT)
colnames(GP)[1]="Total Pop"
GP$Area <- c("Watford","Hemel Hempstead","Stevenage","St Albans","Welwyn Garden City")
GP$Mode <- "C"
GP$Destination <- Destination
GP

PT_WFDT <- subset(PT_GP, PT_GP$Area=="Watford")
PT_WFDT  <- sum(PT_WFDT$Population)
PT_HHT <- subset(PT_GP, PT_GP$Area=="Hemel Hempstead")
PT_HHT  <- sum(PT_HHT$Population)
PT_SVGT <- subset(PT_GP, PT_GP$Area=="Stevenage")
PT_SVGT  <- sum(PT_SVGT$Population)
PT_STAT <- subset(PT_GP, PT_GP$Area=="St Albans")
PT_STAT  <- sum(PT_STAT$Population)
PT_WGCT <- subset(PT_GP, PT_GP$Area=="Welwyn Garden City")
PT_WGCT  <- sum(PT_WGCT$Population)
TPT <- rbind.data.frame(PT_WFDT,PT_HHT,PT_SVGT,PT_STAT,PT_WGCT)
colnames(TPT)[1]="Total Pop"
TPT$Area <- c("Watford","Hemel Hempstead","Stevenage","St Albans","Welwyn Garden City")
TPT$Mode <- "PT"
TPT$Destination <- Destination
TPT

Output1 <- rbind.data.frame(TW,GP,TPT)
Output2 <- rbind.data.frame(W_GP,C_GP,PT_GP)
Output1
Output2

write.csv(Output1,"01_BUA_GP-TOTAL.csv",row.names = FALSE)
write.csv(Output2,"01_BUA_GP-BAND.csv",row.names = FALSE)

rm(list=setdiff(ls(), "Cent"))
