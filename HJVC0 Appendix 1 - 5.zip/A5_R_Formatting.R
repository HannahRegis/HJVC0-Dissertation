# Working Directory

WD <- getwd()

# Opening Data

R1<- read.csv("PWC_EC_PT.csv",header = TRUE,sep = ',')
Origin <- read.csv("PWCO.csv",header = TRUE, sep = ',')
ncol(R1)

# Data contains multiple observations from each origin point requiring aggregation. 
## Aggregating Origin Points for Median

R2 <- aggregate(R1[,11],by=list(R1$OriginId),FUN = "median")
colnames(R2)[1] = "OriginId"
colnames(R2)[2] = "Time_Median"
head(R2)

## Aggregating Origin Points for Mean

T3 <- aggregate(R1[,11],by=list(R1$OriginId),FUN = "mean")
colnames(T3)[1] = "OriginId"
colnames(T3)[2] = "Time_Mean"
head(T3)

## Binding Median and Mean Together

OP1 <- cbind(R2,T3$Time_Mean)
head(OP1)

## Aggregating to Calculate Accessible Services

T1_1 <- as.data.frame(table(R1$OriginId))
colnames(T1_1)[2] = "ServiceCount"

## Binding Outputs

OP1 <- cbind(OP1,T1_1$ServiceCount)
colnames(OP1)[3] = "Time_Mean"
colnames(OP1)[4] = "ServiceCount"
head(OP1)

# Origin Work

nrow(OP1) 
nrow(Origin) #9599

R4 <- merge(Origin, OP1,
            by = "OriginId",
            all = TRUE)

# Tidying Final Output for Analysis and QGIS

R4$OriginHeaderId<- NULL
R4$WeightFactor<- NULL
R4$OdId<- NULL
R4$Name<- NULL
R4$Suspend<- NULL
R4$Id<- NULL
R4$Is3D<- NULL
R4$Z<- NULL
R4$LocationWKT<- NULL
R4$COREID<- NULL
R4["Med_Rounded"] <- round(R4$Time_Median,0)
R4["Mean_Rounded"] <- round(R4$Time_Mean,0)
R4["OriginType"] <-'PWC'
R4["Destination"] <-'EmploymentCentre'
R4["Mode"] <-'Bus'
head(R4)

# QGIS

R5 <- R4
R5$Time_Median[is.na(R5$Time_Median)] <- 1000
R5$Time_Mean[is.na(R5$Time_Mean)] <- 1000
R5$ServiceCount[is.na(R5$ServiceCount)] <- 0
nrow(R5)


# Exporting Output

write.csv(R4,file="PWC_PT_EC_R.csv",row.names = FALSE)
write.csv(R5,file="PWC_PT_EC_Q.csv",row.names = FALSE)

