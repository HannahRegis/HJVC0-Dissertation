# Opening Data

## Tidying for Repeats

BUAF <- read.csv("BUA_AnalysisFINAL.csv",header = TRUE, sep = ',')
BUAF$AreaCode=as.factor(BUAF$AreaCode)
class(BUAF$AreaCode)

# Looking at Data

nrow(BUAF)
summary(BUAF$Destination)

# Installing Packages

library("sjstats")
library("survey")

# Statistical Test
# P-Value > 0.05 ACCEPT H0 "The distribution of scores for the groups are equal"
# P-Value < 0.05 REJECT H0 "The distribution of scores for the groups are NOT equal"

#\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\

# Subsetting Data

SVG <- subset(BUAF, BUAF$Name=="Stevenage")
STA <- subset(BUAF, BUAF$Name=="St Albans")
DS<- rbind(SVG,STA)
(nrow(STA)+nrow(SVG))==nrow(DS)

TC_Walk <- subset(DS, DS$Destination=="TC" & DS$Mode=='W')
TC_Cycle <- subset(DS, DS$Destination=="TC" & DS$Mode=='C')
TC_Bus <- subset(DS, DS$Destination=="TC" & DS$Mode=='PT')

# Checking Subset

C1<- nrow(TC_Bus)+nrow(TC_Cycle)+nrow(TC_Walk)
C2 <- nrow((subset(DS, DS$Destination=="TC")))
C1==C2

# Weighting Data
summary(BUAF$Name)

A1 <- subset(TC_Walk,TC_Walk$Name=="Stevenage")
B1 <- subset(TC_Walk,TC_Walk$Name=="St Albans")
AR1 <- nrow(A1)
BR1 <- nrow(B1)
TR1 <- AR1+BR1
AP1 <- (AR1/TR1)*100
BP1 <- (BR1/TR1)*100
AW1 <- 50/AP1
BW1 <- 50/BP1
A1$Weight <- AW1
B1$Weight <- BW1
TC_Walk<- rbind(A1,B1)
TC_Walk$W8Time <- round((TC_Walk$Time*TC_Walk$Weight),0)
TC_Walk$TimeR <- round(TC_Walk$Time,0)
head(TC_Walk)

#/\/\/\/\/\

A2 <- subset(TC_Cycle,TC_Cycle$Name=="Stevenage")
B2 <- subset(TC_Cycle,TC_Cycle$Name=="St Albans")
AR2 <- nrow(A2)
BR2 <- nrow(B2)
TR2 <- AR2+BR2
AP2 <- (AR2/TR2)*100
BP2 <- (BR2/TR2)*100
AW2 <- 50/AP2
BW2 <- 50/BP2
A2$Weight <- AW2
B2$Weight <- BW2
TC_Cycle<- rbind(A2,B2)
TC_Cycle$W8Time <- round((TC_Cycle$Time*TC_Cycle$Weight),0)
TC_Cycle$TimeR <- round(TC_Cycle$Time,0)
head(TC_Cycle)

#/\/\/\/\/\

A3 <- subset(TC_Bus,TC_Bus$Name=="Stevenage")
B3 <- subset(TC_Bus,TC_Bus$Name=="St Albans")
AR3 <- nrow(A3)
BR3 <- nrow(B3)
TR3 <- AR3+BR3
AP3 <- (AR3/TR3)*100
BP3 <- (BR3/TR3)*100
AW3 <- 50/AP3
BW3 <- 50/BP3
A3$Weight <- AW3
B3$Weight <- BW3
TC_Bus<- rbind(A3,B3)
TC_Bus$W8Time <- round((TC_Bus$Time*TC_Bus$Weight),0)
TC_Bus$TimeR <- round(TC_Bus$Time,0)
head(TC_Bus)

#/\/\/\/\/\


# Difference between Towns and Walk

wilcox.test(TC_Walk$TimeR~TC_Walk$AreaCode)
TPV <- wilcox.test(TC_Walk$TimeR~TC_Walk$AreaCode)
TPV$p.value
TPV$p.value < 0.05

# REJECT H0 There is  A SIGNIFICANT difference. 

summary((round(A1$Time,0))) # Stevenage Quicker
summary((round(B1$Time,0))) 

# Difference between BUA and Cycle

wilcox.test(TC_Cycle$TimeR~TC_Cycle$AreaCode)
TPV <- wilcox.test(TC_Cycle$TimeR~TC_Cycle$AreaCode)
TPV$p.value
TPV$p.value < 0.05

# REJECT H0 There is  A NO SIGNIFICANT difference. 

summary((round(A2$Time,0))) # Stevenage Quicker
summary((round(B2$Time,0))) 

# Difference between BUA and Bus

wilcox.test(TC_Bus$TimeR~TC_Bus$AreaCode)
TPV <- wilcox.test(TC_Bus$TimeR~TC_Bus$AreaCode)
TPV$p.value
TPV$p.value < 0.05

# REJECT H0 There is a difference. 

summary((round(A3$Time,0))) # Stevenage Quicker
summary((round(B3$Time,0))) 

# There are insignificant differences between walking.
# Hemel is generally quicker.

rm(list=setdiff(ls(), "BUAF"))
