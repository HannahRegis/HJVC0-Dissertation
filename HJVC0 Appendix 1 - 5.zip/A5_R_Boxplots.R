# Opening Packages

library(dplyr)
library(ggplot2)
library(descr)
library("gridExtra")
library("scales")

# Formatting Data

A1 <- read.csv("O2RU_AnalysisFINAL.csv",header = TRUE, sep = ',')
Lab <- c(
  '1' = "Walking",
  '2' = "Cycling",
  '3' = "Bus")
R1 <- subset(A1, A1$Area=="1")
U1 <- subset(A1, A1$Area=="2")
R1$Loc <- "Rural"
R1$Col <- "#B2DF8A"
U1$Loc <- "Urban"
U1$Col <- "#56B0C8"
A1 <- rbind.data.frame(R1,U1)
W1 <- subset(A1, A1$Mode=="W")
C1 <- subset(A1, A1$Mode=="C")
PT1 <- subset(A1, A1$Mode=="PT")
W1$Order <- "1"
C1$Order <- "2"
PT1$Order <- "3"
A1 <- rbind.data.frame(W1,C1,PT1)
A1$Order=as.factor(A1$Order)
A1$Loc=as.factor(A1$Loc)
A1$Mode=as.factor(A1$Mode)
A1$Area=as.factor(A1$Area)
A1$Time_R=round(A1$Time,0)

head(GP1)


GP1 <- subset(A1, A1$Destination=="GP")
HE1 <- subset(A1, A1$Destination=="HE")
PS1 <- subset(A1, A1$Destination=="PS")
SM1 <- subset(A1, A1$Destination=="SM")
SS1 <- subset(A1, A1$Destination=="SS")
TC1 <- subset(A1, A1$Destination=="TC")
TS1 <- subset(A1, A1$Destination=="TS")

## Plotting GP

GP2 <- ggplot(GP1, aes(x=as.factor(Loc), y=Time_R), fill=Mode) + 
  geom_boxplot(color="black",
               notch = TRUE,
               notchwidth = 0.8) +
  labs(x="Area Classification",
       y="Time (Minutes)",
       title = "GP Travel Times") +
  theme(plot.title = element_text(hjust=0.5,
                                  vjust = 2,
                                  face = "bold",
                                  size = 14),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray", linetype = "dotted",size = 0.5),
        panel.grid.minor = element_line(colour = "gray", linetype = "dotted", size = 0.5),
        strip.background = element_rect(colour="black", fill="white", 
                                        size=1, linetype="solid"),
        strip.text.x = element_text(size=11, 
                                    color="black",
                                    face="bold.italic")) +
  facet_wrap(~Order,labeller = as_labeller(Lab)) 
GP2 + geom_boxplot(aes(fill = Loc),
                  notch = TRUE,
                  notchwidth = 0.8) +
  theme(legend.position = "bottom",
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())+
  scale_fill_manual(values = c("#B2DF8A", "#56B0C8"),
                    name="Area Classification: ")

# Primary School

PS2 <- ggplot(PS1, aes(x=as.factor(Loc), y=Time_R), fill=Mode) + 
  geom_boxplot(color="black",
               notch = TRUE,
               notchwidth = 0.8) +
  labs(x="Area Classification",
       y="Time (Minutes)",
       title = "Primary School Travel Times") +
  theme(plot.title = element_text(hjust=0.5,
                                  vjust = 2,
                                  face = "bold",
                                  size = 14),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray", linetype = "dotted",size = 0.5),
        panel.grid.minor = element_line(colour = "gray", linetype = "dotted", size = 0.5),
        strip.background = element_rect(colour="black", fill="white", 
                                        size=1, linetype="solid"),
        strip.text.x = element_text(size=11, 
                                    color="black",
                                    face="bold.italic")) +
  facet_wrap(~Order,labeller = as_labeller(Lab)) 
PS2 + geom_boxplot(aes(fill = Loc),
                  notch = TRUE,
                  notchwidth = 0.8) +
  theme(legend.position = "bottom",
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())+
  scale_fill_manual(values = c("#B2DF8A", "#56B0C8"),
                    name="Area Classification: ")

# Higher Education

HE2 <- ggplot(HE1, aes(x=as.factor(Loc), y=Time_R), fill=Mode) + 
  geom_boxplot(color="black",
               notch = TRUE,
               notchwidth = 0.8) +
  labs(x="Area Classification",
       y="Time (Minutes)",
       title = "Higher Education Travel Times") +
  theme(plot.title = element_text(hjust=0.5,
                                  vjust = 2,
                                  face = "bold",
                                  size = 14),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray", linetype = "dotted",size = 0.5),
        panel.grid.minor = element_line(colour = "gray", linetype = "dotted", size = 0.5),
        strip.background = element_rect(colour="black", fill="white", 
                                        size=1, linetype="solid"),
        strip.text.x = element_text(size=11, 
                                    color="black",
                                    face="bold.italic")) +
  facet_wrap(~Order,labeller = as_labeller(Lab)) 
HE2 + geom_boxplot(aes(fill = Loc),
                   notch = TRUE,
                   notchwidth = 0.8) +
  theme(legend.position = "bottom",
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())+
  scale_fill_manual(values = c("#B2DF8A", "#56B0C8"),
                    name="Area Classification: ")

# Supermarket

SM2 <- ggplot(SM1, aes(x=as.factor(Loc), y=Time_R), fill=Mode) + 
  geom_boxplot(color="black",
               notch = TRUE,
               notchwidth = 0.8) +
  labs(x="Area Classification",
       y="Time (Minutes)",
       title = "Supermarket Travel Times") +
  theme(plot.title = element_text(hjust=0.5,
                                  vjust = 2,
                                  face = "bold",
                                  size = 14),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray", linetype = "dotted",size = 0.5),
        panel.grid.minor = element_line(colour = "gray", linetype = "dotted", size = 0.5),
        strip.background = element_rect(colour="black", fill="white", 
                                        size=1, linetype="solid"),
        strip.text.x = element_text(size=11, 
                                    color="black",
                                    face="bold.italic")) +
  facet_wrap(~Order,labeller = as_labeller(Lab)) 
SM2 + geom_boxplot(aes(fill = Loc),
                   notch = TRUE,
                   notchwidth = 0.8) +
  theme(legend.position = "bottom",
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())+
  scale_fill_manual(values = c("#B2DF8A", "#56B0C8"),
                    name="Area Classification: ")

# Secondary Schools

SS2 <- ggplot(SS1, aes(x=as.factor(Loc), y=Time_R), fill=Mode) + 
  geom_boxplot(color="black",
               notch = TRUE,
               notchwidth = 0.8) +
  labs(x="Area Classification",
       y="Time (Minutes)",
       title = "Secondary School Travel Times") +
  theme(plot.title = element_text(hjust=0.5,
                                  vjust = 2,
                                  face = "bold",
                                  size = 14),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray", linetype = "dotted",size = 0.5),
        panel.grid.minor = element_line(colour = "gray", linetype = "dotted", size = 0.5),
        strip.background = element_rect(colour="black", fill="white", 
                                        size=1, linetype="solid"),
        strip.text.x = element_text(size=11, 
                                    color="black",
                                    face="bold.italic")) +
  facet_wrap(~Order,labeller = as_labeller(Lab)) 
SS2 + geom_boxplot(aes(fill = Loc),
                   notch = TRUE,
                   notchwidth = 0.8) +
  theme(legend.position = "bottom",
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())+
  scale_fill_manual(values = c("#B2DF8A", "#56B0C8"),
                    name="Area Classification: ")

# Town Centre

TC2 <- ggplot(TC1, aes(x=as.factor(Loc), y=Time_R), fill=Mode) + 
  geom_boxplot(color="black",
               notch = TRUE,
               notchwidth = 0.8) +
  labs(x="Area Classification",
       y="Time (Minutes)",
       title = "Town Centre Travel Times") +
  theme(plot.title = element_text(hjust=0.5,
                                  vjust = 2,
                                  face = "bold",
                                  size = 14),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray", linetype = "dotted",size = 0.5),
        panel.grid.minor = element_line(colour = "gray", linetype = "dotted", size = 0.5),
        strip.background = element_rect(colour="black", fill="white", 
                                        size=1, linetype="solid"),
        strip.text.x = element_text(size=11, 
                                    color="black",
                                    face="bold.italic")) +
  facet_wrap(~Order,labeller = as_labeller(Lab)) 
TC2 + geom_boxplot(aes(fill = Loc),
                   notch = TRUE,
                   notchwidth = 0.8) +
  theme(legend.position = "bottom",
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())+
  scale_fill_manual(values = c("#B2DF8A", "#56B0C8"),
                    name="Area Classification: ")


# Train Station

TS2 <- ggplot(TS1, aes(x=as.factor(Loc), y=Time_R), fill=Mode) + 
  geom_boxplot(color="black",
               notch = TRUE,
               notchwidth = 0.8) +
  labs(x="Area Classification",
       y="Time (Minutes)",
       title = "Train Station Travel Times") +
  theme(plot.title = element_text(hjust=0.5,
                                  vjust = 2,
                                  face = "bold",
                                  size = 14),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray", linetype = "dotted",size = 0.5),
        panel.grid.minor = element_line(colour = "gray", linetype = "dotted", size = 0.5),
        strip.background = element_rect(colour="black", fill="white", 
                                        size=1, linetype="solid"),
        strip.text.x = element_text(size=11, 
                                    color="black",
                                    face="bold.italic")) +
  facet_wrap(~Order,labeller = as_labeller(Lab)) 
TS2 + geom_boxplot(aes(fill = Loc),
                   notch = TRUE,
                   notchwidth = 0.8) +
  theme(legend.position = "bottom",
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())+
  scale_fill_manual(values = c("#B2DF8A", "#56B0C8"),
                    name="Area Classification: ")


## Summary Statistics

A2 <- read.csv("02RU_AnalysisFINAL.csv",header = TRUE, sep = ',')
A2$Order=as.factor(A2$Order)



# Establishing Dest

Dest <- "TS"

#Walking
R1 <- subset(A2, A2$Destination==Dest & A2$Loc=="Rural" & A2$Mode=="W")
U1 <- subset(A2, A2$Destination==Dest & A2$Loc=="Urban" & A2$Mode=="W")
R1<- summary(R1$Time_R)
U1<- summary(U1$Time_R)
R1<- data.frame(rbind(R1))
U1 <- data.frame(rbind(U1))
R1$Loc <- "Rural"
U1$Loc <- "Urban"
OutputW <- rbind.data.frame(R1,U1)
OutputW$Mode <- "Walking"
OutputW$Dest <- Dest
# Cycling
R2 <- subset(A2, A2$Destination==Dest & A2$Loc=="Rural" & A2$Mode=="C")
U2 <- subset(A2, A2$Destination==Dest & A2$Loc=="Urban" & A2$Mode=="C")
R2<- summary(R2$Time_R)
U2<- summary(U2$Time_R)
R2<- data.frame(rbind(R2))
U2 <- data.frame(rbind(U2))
R2$Loc <- "Rural"
U2$Loc <- "Urban"
OutputC <- rbind.data.frame(R2,U2)
OutputC$Mode <- "Cycling"
OutputC$Dest <- Dest
# Bus Travel
R3 <- subset(A2, A2$Destination==Dest & A2$Loc=="Rural" & A2$Mode=="C")
U3 <- subset(A2, A2$Destination==Dest & A2$Loc=="Urban" & A2$Mode=="C")
R3<- summary(R3$Time_R)
U3<- summary(U3$Time_R)
R3<- data.frame(rbind(R3))
U3 <- data.frame(rbind(U3))
R3$Loc <- "Rural"
U3$Loc <- "Urban"
OutputPT <- rbind.data.frame(R3,U3)
OutputPT$Mode <- "Bus"
OutputPT$Dest <- Dest

# Final Output
OutputFinal <- rbind.data.frame(OutputW,OutputC,OutputPT)
head(OutputFinal)

# Saving
write.csv(OutputFinal,"03RU_TS_DS.csv",row.names = FALSE)

rm(list=setdiff(ls(), "A2"))


# Final Merge
GP <- read.csv("03RU_GP_DS.csv",header = TRUE, sep = ',')
HE <- read.csv("03RU_HE_DS.csv",header = TRUE, sep = ',')
PS <- read.csv("03RU_PS_DS.csv",header = TRUE, sep = ',')
SM <- read.csv("03RU_SM_DS.csv",header = TRUE, sep = ',')
SS <- read.csv("03RU_SS_DS.csv",header = TRUE, sep = ',')
TC <- read.csv("03RU_TC_DS.csv",header = TRUE, sep = ',')
TS <- read.csv("03RU_TS_DS.csv",header = TRUE, sep = ',')
M1 <- rbind.data.frame(GP,HE,PS,SM,SS,TC,TS)
write.csv(M1,"03RU_DescriptiveFINAL.csv",row.names = FALSE)
