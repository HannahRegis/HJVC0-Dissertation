# Opening Data

BUAF <- read.csv("BUA_AnalysisFINAL.csv",header = TRUE, sep = ',')
BUAF$AreaCode=as.factor(BUAF$AreaCode)
names(BUAF)
# Looking at Data

nrow(BUAF)
names(BUAF)

# Installing Packages

library("sjstats")
library("survey")

# Statistical Test
# P-Value > 0.05 ACCEPT H0 "The distribution of scores for the groups are equal"
# P-Value < 0.05 REJECT H0 "The distribution of scores for the groups are NOT equal"

#\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
# PRIMARY SCHOOL

# Subsetting Data

TS_Walk <- subset(BUAF, BUAF$Destination=="TS" & BUAF$Mode=='W')
TS_Cycle <- subset(BUAF, BUAF$Destination=="TS" & BUAF$Mode=='C')
TS_Bus <- subset(BUAF, BUAF$Destination=="TS" & BUAF$Mode=='PT')

# Checking Subset

C1<- nrow(TS_Bus)+nrow(TS_Cycle)+nrow(TS_Walk)
C2 <- nrow((subset(BUAF, BUAF$Destination=="TS")))
C1==C2

# Weighting Data
summary(BUAF$Name)

A <- subset(TS_Walk,TS_Walk$Name=="Watford")
B <- subset(TS_Walk,TS_Walk$Name=="Hemel Hempstead")
C <- subset(TS_Walk,TS_Walk$Name=="Stevenage")
D <- subset(TS_Walk,TS_Walk$Name=="St Albans")
E <- subset(TS_Walk,TS_Walk$Name=="Welwyn Garden City")
A1 <- nrow(A)
B1 <- nrow(B)
C1 <- nrow(C)
D1 <- nrow(D)
E1 <- nrow(E)
TR1 <- A1+B1+C1+D1+E1
AP1 <- (A1/TR1)*100
BP1 <- (B1/TR1)*100
CP1 <- (C1/TR1)*100
DP1 <- (D1/TR1)*100
EP1 <- (E1/TR1)*100
AW1 <- 20/AP1
BW1 <- 20/BP1
CW1 <- 20/CP1
DW1 <- 20/DP1
EW1 <- 20/EP1
A$Weight <- AW1
B$Weight <- BW1
C$Weight <- CW1
D$Weight <- DW1
E$Weight <- EW1
TS_Walk<- rbind(A,B,C,D,E)
TS_Walk$W8Time <- round((TS_Walk$Time*TS_Walk$Weight),0)
TS_Walk$TimeR <- round(TS_Walk$Time,0)
head(TS_Walk)

#/\/\/\/\/\

A_2 <- subset(TS_Cycle,TS_Cycle$Name=="Watford")
B_2 <- subset(TS_Cycle,TS_Cycle$Name=="Hemel Hempstead")
C_2 <- subset(TS_Cycle,TS_Cycle$Name=="Stevenage")
D_2 <- subset(TS_Cycle,TS_Cycle$Name=="St Albans")
E_2 <- subset(TS_Cycle,TS_Cycle$Name=="Welwyn Garden City")
A2 <- nrow(A_2)
B2 <- nrow(B_2)
C2 <- nrow(C_2)
D2 <- nrow(D_2)
E2 <- nrow(E_2)
TR2 <- A2+B2+C2+D2+E2
AP2 <- (A2/TR2)*100
BP2 <- (B2/TR2)*100
CP2 <- (C2/TR2)*100
DP2 <- (D2/TR2)*100
EP2 <- (E2/TR2)*100
AW2 <- 20/AP2
BW2 <- 20/BP2
CW2 <- 20/CP2
DW2 <- 20/DP2
EW2 <- 20/EP2
A_2$Weight <- AW2
B_2$Weight <- BW2
C_2$Weight <- CW2
D_2$Weight <- DW2
E_2$Weight <- EW2
TS_Cycle<- rbind(A_2,B_2,C_2,D_2,E_2)
TS_Cycle$W8Time <- round((TS_Cycle$Time*TS_Cycle$Weight),0)
TS_Cycle$TimeR <- round(TS_Cycle$Time,0)
head(TS_Cycle)

#/\/\/\/\/\

A_3 <- subset(TS_Bus,TS_Bus$Name=="Watford")
B_3 <- subset(TS_Bus,TS_Bus$Name=="Hemel Hempstead")
C_3 <- subset(TS_Bus,TS_Bus$Name=="Stevenage")
D_3 <- subset(TS_Bus,TS_Bus$Name=="St Albans")
E_3 <- subset(TS_Bus,TS_Bus$Name=="Welwyn Garden City")
A3 <- nrow(A_3)
B3 <- nrow(B_3)
C3 <- nrow(C_3)
D3 <- nrow(D_3)
E3 <- nrow(E_3)
TR3 <- A3+B3+C3+D3+E3
AP3 <- (A3/TR3)*100
BP3 <- (B3/TR3)*100
CP3 <- (C3/TR3)*100
DP3 <- (D3/TR3)*100
EP3 <- (E3/TR3)*100
AW3 <- 20/AP3
BW3 <- 20/BP3
CW3 <- 20/CP3
DW3 <- 20/DP3
EW3 <- 20/EP3
A_3$Weight <- AW3
B_3$Weight <- BW3
C_3$Weight <- CW3
D_3$Weight <- DW3
E_3$Weight <- EW3
TS_Bus<- rbind(A_3,B_3,C_3,D_3,E_3)
TS_Bus$W8Time <- round((TS_Bus$Time*TS_Bus$Weight),0)
TS_Bus$TimeR <- round(TS_Bus$Time,0)
head(TS_Bus)

#/\/\/\/\/\


# Difference between BUA and Walk to TS

kruskal.test(TS_Walk$TimeR~TS_Walk$AreaCode)
WPV<- kruskal.test(TS_Walk$TimeR~TS_Walk$AreaCode)
WPV$p.value
WPV$p.value < 0.05

summary(A$Time)
summary(B$Time)
summary(C$Time)
summary(D$Time)
summary(E$Time)


# Difference between BUA and Cycle to TS

kruskal.test(TS_Cycle$TimeR~TS_Cycle$AreaCode)
CPV <- kruskal.test(TS_Cycle$TimeR~TS_Cycle$AreaCode)
CPV$p.value
CPV$p.value < 0.05

summary(A_2$Time)
summary(B_2$Time)
summary(C_2$Time)
summary(D_2$Time)
summary(E_2$Time)

# Difference between BUA and Bus to TS

kruskal.test(TS_Bus$TimeR~TS_Bus$AreaCode)
BPV <- kruskal.test(TS_Bus$TimeR~TS_Bus$AreaCode)
BPV$p.value
BPV$p.value < 0.05

summary(A_3$Time)
summary(B_3$Time)
summary(C_3$Time)
summary(D_3$Time)
summary(E_3$Time)

rm(list=setdiff(ls(), "BUAF"))
